"""Google Gemini AI client - 100% FREE, no credit card needed.
Get your free API key at: https://aistudio.google.com/app/apikey
Uses gemini-2.5-flash (latest free model as of 2026)
"""
import os
import httpx
from app.config import get_settings

settings = get_settings()

GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"


def gemini_chat(system_prompt: str, user_prompt: str) -> str:
    """
    Send a message to Google Gemini API.
    Completely FREE - just needs GEMINI_API_KEY in your .env file.
    Get free key at: https://aistudio.google.com/app/apikey
    """
    api_key = settings.GEMINI_API_KEY
    if not api_key:
        return (
            "[AI Error: GEMINI_API_KEY not set. "
            "Get your FREE key at https://aistudio.google.com/app/apikey "
            "and add GEMINI_API_KEY=your-key to your backend .env file]"
        )

    try:
        full_prompt = f"{system_prompt}\n\n{user_prompt}"
        payload = {
            "contents": [
                {
                    "parts": [{"text": full_prompt}]
                }
            ],
            "generationConfig": {
                "maxOutputTokens": 2048,
                "temperature": 0.7,
            },
        }

        with httpx.Client(timeout=90.0) as client:
            response = client.post(
                f"{GEMINI_API_URL}?key={api_key}",
                json=payload,
                headers={"Content-Type": "application/json"},
            )
            data = response.json()

            if response.status_code != 200:
                err = data.get("error", {}).get("message", str(data))
                return f"[AI Error: {err}]"

            candidates = data.get("candidates", [])
            if not candidates:
                return "[AI Error: No response from Gemini. Please try again.]"

            parts = candidates[0].get("content", {}).get("parts", [])
            if not parts:
                return "[AI Error: Empty response from Gemini.]"

            return parts[0].get("text", "[AI Error: Could not extract text from response.]")

    except httpx.TimeoutException:
        return "[AI Error: Request timed out. Please try again.]"
    except Exception as e:
        return f"[AI Error: {str(e)}]"


# Backward compatibility aliases used throughout the codebase
def ollama_chat(system_prompt: str, user_prompt: str, model: str | None = None) -> str:
    return gemini_chat(system_prompt, user_prompt)


def claude_chat(system_prompt: str, user_prompt: str) -> str:
    return gemini_chat(system_prompt, user_prompt)
