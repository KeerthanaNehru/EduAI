"""Shim — all AI now goes through Gemini (free)."""
from .gemini_client import gemini_chat
def claude_chat(system_prompt: str, user_prompt: str) -> str:
    return gemini_chat(system_prompt, user_prompt)
def ollama_chat(system_prompt: str, user_prompt: str, model=None) -> str:
    return gemini_chat(system_prompt, user_prompt)
