import { useState, useEffect } from 'react'
import api from '../api/axios'

export default function StudentQuizzes() {
  const [quizzes, setQuizzes] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeQuiz, setActiveQuiz] = useState(null)
  const [answers, setAnswers] = useState({})
  const [submitted, setSubmitted] = useState(null)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    api.get('/quiz/available').then(({ data }) => setQuizzes(data)).catch(() => setQuizzes([])).finally(() => setLoading(false))
  }, [])

  const startQuiz = (quiz) => { setActiveQuiz(quiz); setAnswers({}); setSubmitted(null) }

  const handleSubmit = async () => {
    setSubmitting(true)
    try {
      const { data } = await api.post(`/quiz/${activeQuiz.id}/submit`, { answers })
      setSubmitted(data)
    } catch (err) { alert(err.response?.data?.detail || 'Submission failed.') }
    setSubmitting(false)
  }

  if (activeQuiz) return (
    <div>
      <button onClick={() => setActiveQuiz(null)} style={{ background:'none', border:'none', color:'#7c3aed', cursor:'pointer', fontFamily:'Syne,sans-serif', fontSize:'0.875rem', marginBottom:'20px', padding:0 }}>← Back to Quizzes</button>
      <h1 className="section-title" style={{ marginBottom:'6px' }}>{activeQuiz.title}</h1>
      <p style={{ color:'#64748b', fontSize:'0.875rem', marginBottom:'24px' }}>Subject: {activeQuiz.subject?.replace('_',' ')}</p>

      {submitted ? (
        <div className="card-dark" style={{ padding:'36px', textAlign:'center' }}>
          <p style={{ fontFamily:'Orbitron', fontSize:'2rem', color:'#a855f7', margin:'0 0 8px' }}>{submitted.score} / {submitted.total}</p>
          <p style={{ color: submitted.score >= submitted.total/2 ? '#4ade80' : '#f87171', fontWeight:600 }}>
            {submitted.score >= submitted.total ? '🎉 Perfect!' : submitted.score >= submitted.total/2 ? '👍 Good job!' : '💪 Keep practicing!'}
          </p>
          <button className="btn-purple" onClick={() => setActiveQuiz(null)} style={{ marginTop:'20px' }}>Back to Quizzes</button>
        </div>
      ) : (
        <div>
          <div style={{ display:'grid', gap:'14px', marginBottom:'20px' }}>
            {(activeQuiz.questions || []).map((q, i) => (
              <div key={i} className="card-dark" style={{ padding:'20px' }}>
                <p style={{ color:'#e2e8f0', fontWeight:600, marginBottom:'12px' }}>{i+1}. {q.question_text}</p>
                <div style={{ display:'grid', gap:'8px' }}>
                  {(q.options||[]).map((opt, j) => {
                    const letter = String.fromCharCode(65+j)
                    const sel = answers[i] === letter
                    return (
                      <label key={j} style={{ display:'flex', alignItems:'center', gap:'10px', padding:'9px 14px', borderRadius:'8px', cursor:'pointer', background: sel?'rgba(168,85,247,0.1)':'rgba(255,255,255,0.03)', border: sel?'1px solid rgba(168,85,247,0.3)':'1px solid #1e1030' }}>
                        <input type="radio" name={`q${i}`} onChange={() => setAnswers(p=>({...p,[i]:letter}))} checked={sel} style={{ accentColor:'#a855f7' }} />
                        <span style={{ color: sel?'#c084fc':'#e2e8f0', fontSize:'0.875rem' }}>{opt}</span>
                      </label>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
          <button className="btn-purple" onClick={handleSubmit} disabled={submitting}>{submitting?'Submitting...':'Submit Quiz'}</button>
        </div>
      )}
    </div>
  )

  return (
    <div>
      <h1 className="section-title" style={{ marginBottom:'8px' }}>📝 Teacher Quizzes</h1>
      <p style={{ color:'#64748b', fontSize:'0.875rem', marginBottom:'24px' }}>Quizzes posted by your teachers — complete them and track your progress.</p>
      {loading && <p style={{ color:'#64748b' }}>Loading quizzes...</p>}
      {!loading && quizzes.length === 0 && (
        <div className="card-dark" style={{ padding:'48px', textAlign:'center', color:'#475569' }}>
          <div style={{ fontSize:'3rem', marginBottom:'12px' }}>📭</div>
          <p>No quizzes posted yet. Check back later!</p>
        </div>
      )}
      <div style={{ display:'grid', gap:'14px' }}>
        {quizzes.map(q => (
          <div key={q.id} className="card-dark" style={{ padding:'22px 26px', display:'flex', justifyContent:'space-between', alignItems:'center', gap:'16px' }}>
            <div>
              <h3 style={{ margin:'0 0 6px', color:'#e2e8f0', fontWeight:700 }}>{q.title}</h3>
              <p style={{ margin:0, color:'#64748b', fontSize:'0.8rem' }}>{q.subject?.replace('_',' ')} · {(q.questions||[]).length} questions</p>
              {q.description && <p style={{ margin:'6px 0 0', color:'#94a3b8', fontSize:'0.8rem' }}>{q.description}</p>}
            </div>
            <button className="btn-purple" onClick={() => startQuiz(q)} style={{ padding:'8px 22px', fontSize:'0.85rem', whiteSpace:'nowrap' }}>Start Quiz →</button>
          </div>
        ))}
      </div>
    </div>
  )
}
